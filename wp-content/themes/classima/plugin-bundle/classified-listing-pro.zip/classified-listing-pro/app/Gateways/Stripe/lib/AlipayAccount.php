<?php

namespace Rtcl\Gateways\Stripe\lib;

/**
 * Class AlipayAccount
 *
 * @package Stripe
 */
class AlipayAccount extends ExternalAccount
{

}
