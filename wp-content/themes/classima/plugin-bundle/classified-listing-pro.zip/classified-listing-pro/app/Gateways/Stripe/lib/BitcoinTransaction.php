<?php

namespace Rtcl\Gateways\Stripe\lib;

/**
 * Class BitcoinTransaction
 *
 * @package Stripe
 */
class BitcoinTransaction extends ApiResource
{

}
