<?php

namespace Rtcl\Gateways\Stripe\lib;

/**
 * Class Card
 *
 * @package Stripe
 */
class Card extends ExternalAccount
{

}
