<?php

namespace Rtcl\Gateways\Stripe\lib\Error;

class Api extends Base
{
}
