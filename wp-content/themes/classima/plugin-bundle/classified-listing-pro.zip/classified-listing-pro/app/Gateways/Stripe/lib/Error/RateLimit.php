<?php

namespace Rtcl\Gateways\Stripe\lib\Error;

class RateLimit extends InvalidRequest
{
}
