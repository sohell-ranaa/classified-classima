<?php

namespace Rtcl\Log;

class InvalidArgumentException extends \InvalidArgumentException {
}
