<?php
/**
 * Result Count
 *
 */
?>

<div class="rtcl-listings-actions">
    <?php do_action('rtcl_listing_loop_action'); ?>
</div>
