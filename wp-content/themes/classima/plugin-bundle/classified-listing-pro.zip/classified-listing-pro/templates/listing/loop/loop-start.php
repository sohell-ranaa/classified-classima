<?php
/**
 * @package ClassifiedListing/Templates
 * @version 1.4.0
 */

use Rtcl\Helpers\Functions;

defined( 'ABSPATH' ) || exit();
?>

<div <?php Functions::listing_loop_start_class() ?>>
