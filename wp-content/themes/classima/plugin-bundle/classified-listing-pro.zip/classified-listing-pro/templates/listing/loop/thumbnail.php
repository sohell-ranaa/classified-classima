<?php

global $listing;

?>
<div class="listing-thumb">
    <a href="<?php the_permalink(); ?>" class="rtcl-media"><?php $listing->the_thumbnail(); ?></a>
</div>
