<?php
/**
 * @package ClassifiedListing/Templates
 * @version 1.4.0
 */

use Rtcl\Helpers\Functions;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

Functions::get_template('archive-rtcl_listing');