<?php
/**
 * @package ClassifiedListing/Templates
 * @version 1.2.31
 */

defined('ABSPATH') || exit;

?>
<p class="rtcl-info"><?php esc_html_e('No Stores were found matching your selection.', 'classified-listing-store'); ?></p>
